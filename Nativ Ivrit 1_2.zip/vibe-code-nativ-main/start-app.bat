@echo off
chcp 65001 >nul
cd /d "%~dp0"
cls
echo ============================================
echo  Nativ Ivrit - Expo SDK 57
echo ============================================
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js nao encontrado. Instale a versao LTS em https://nodejs.org e rode este arquivo de novo.
  pause
  exit /b 1
)
for /f "tokens=1 delims=." %%v in ('node -p "process.versions.node"') do set NODEMAJOR=%%v
if %NODEMAJOR% LSS 20 (
  echo Seu Node.js e muito antigo. Instale o Node 22 LTS em https://nodejs.org e rode de novo.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Instalando dependencias pela primeira vez, aguarde...
  call npm install
  if errorlevel 1 call npm install --legacy-peer-deps
  call npx expo install --fix
)
echo.
echo Abrindo com TUNEL: o QR code funciona em qualquer Wi-Fi ou 4G.
call npx expo start --tunnel --clear
if errorlevel 1 (
  echo.
  echo O tunel nao abriu. Tentando pela rede local ^(celular e PC no mesmo Wi-Fi^)...
  call npx expo start --clear
)
pause
