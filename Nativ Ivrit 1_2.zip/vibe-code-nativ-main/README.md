# Nativ Ivrit

App para aprender hebraico (Expo SDK 57 / React Native 0.86): funciona no Expo Go e no navegador.

## Como rodar
1. Node 20 ou mais novo (o 22 LTS é o mais seguro). Windows: `start-app.bat`. Mac/Linux: `./iniciar.sh`. Eles conferem o Node, instalam tudo e abrem com túnel.
2. Dê dois cliques em `start-app.bat` (instala tudo na primeira vez) ou, no terminal:
   `npm install` → `npx expo install --fix` → `npx expo start --tunnel -c`
3. Aperte **w** para o navegador, ou escaneie o QR code com o Expo Go (SDK 57).

## Telas (barra de baixo)
- **Trilha** (início): caminho de etapas estilo Duolingo, botão "Continuar", sequência, XP e meta do dia.
- **Estudar**: vogais, alfabeto, palavras, frases, lições (Aprender → Praticar → Concluir) e cartas.
- **Praticar**: 10 modos (misto, revisão, letras, vocabulário, ouvir, vogais, montar palavras, completar, associar, ditado).
- **Israel**: fotos, a viagem por quatro cidades (uma por nível), mapa e personalidades históricas.
- **Perfil**: nível, sequência, meta, gráfico de 7 dias, conquistas, revisão e teste de áudio.

## Como subir de nível
XP mínimo **e** passar na **Prova do nível** (10 questões, 70%). Ao passar: +30 XP e a próxima cidade da viagem. Contas antigas mantêm o nível que já tinham.

## Áudio
Um único serviço (`audioService.js`) usa a voz do aparelho em hebraico. No iPhone a sessão de áudio é ligada em "playback" (`sessaoAudio.ios.js`, pacote `expo-audio`) para tocar mesmo com a chave lateral no silencioso. No navegador, sem voz hebraica, há um áudio online de reserva (não oficial). Em Perfil → "Testar áudio" aparece o diagnóstico.

## Onde mexer
`theme.js` cores · `niveis.js` conteúdo e níveis · `questoes.js` questões e prova · `dadosMissoes.js` missões de escrita · `TecladoHebraico.js` teclado · `dadosIsrael.js` mapa/cultura · `videos.js` atalhos do YouTube · `progresso.js` meta/sequência/conquistas · `userDB.js` + `seguranca.js` contas.

## Segurança
Senha só como hash PBKDF2-SHA256 com salt; bloqueio após 5 erros; dados validados ao ler/gravar. Sem servidor: quem tem acesso ao aparelho pode alterar o XP.

## Fotos e ícones
- Ícones: biblioteca `@expo/vector-icons` (Ionicons), pelo componente `Icone.js`.
- Fotos: Wikimedia Commons (domínio público ou licença livre), carregadas pela internet. Lista, autores e licenças em `fotos.js`; o crédito aparece na tela. Se uma foto não carregar, o app mostra um bloco de cor e continua funcionando.

## Fotos de domínio público e GitHub
As 11 fotos (cidades, lugares e personalidades) são de domínio público, do Wikimedia Commons; autor e licença estão em `fotos.js`.
1. Dê dois cliques em `atualizar-github.bat`: ele baixa as fotos para `assets/fotos/`, gera `fotosLocais.js` e envia tudo para https://github.com/davidperelzon/Projeto-Final.git (pede seu login do GitHub).
2. Sem baixar, o app carrega as fotos pela internet; se falhar, mostra um bloco de cor e continua funcionando.

## Abrir no Expo Go sem estar no mesmo Wi-Fi (túnel)
`start-app.bat` e `npm start` já abrem com `--tunnel`: o QR code funciona em qualquer rede (4G, Wi-Fi diferente). O túnel usa o pacote `@expo/ngrok` (já no `package.json`) e precisa de internet no computador e no celular. Pode demorar alguns segundos a mais. Para usar só a rede local: `npm run lan`.

## Funciona em qualquer máquina
- `.npmrc` evita erros de dependência em qualquer versão do npm; `.nvmrc` indica o Node 22.
- `.gitattributes` mantém as quebras de linha certas no Windows, Mac e Linux.
- Pacotes opcionais (`@expo/vector-icons`, `expo-audio`, `expo-crypto`): se faltarem, o app ainda abre (só perde ícones, o ajuste do silencioso do iPhone ou usa outro gerador de números aleatórios).
- Se o túnel não abrir, os scripts tentam sozinhos pela rede local.
- O Expo Go no celular precisa estar no SDK 57.

## Pastas (cada uma tem um README curto)
`src/audio` serviço de áudio · `src/conta` contas e segurança · `src/dados` conteúdo · `src/logica` regras e questões · `src/componentes` peças reutilizáveis · `src/telas` telas · `src/tema` cores · `src/utilitarios` apoio · `assets` imagens, fotos e mascotes · `scripts` utilitários.

## Regra dos 60%
Para concluir uma tarefa (sessão, lição, quiz de cultura, prova) e ganhar XP é preciso acertar pelo menos 60% (`src/logica/aprovacao.js`). Abaixo disso: 0 XP e é preciso tentar de novo. O XP de cada questão só é concedido uma vez por conta.

## Vogais
Palavras, frases, lições, cartas e nomes de lugares/pessoas até o nível 3 aparecem com vogais (nikkud). Nas questões "Montar palavras" e "Completar" as vogais ficam junto da letra.

## Mascotes
`assets/mascotes` (recortados da folha enviada) e `src/dados/mascotes.js` (qual mascote para cada ocasião). Atenção: os desenhos lembram pessoas reais; para publicar fora da escola, confira direitos de imagem ou troque os arquivos.
