/*
 * src/data/letrasHebraicas.js
 *
 * Dados estruturados das 22 letras do alfabeto hebraico e das 5 formas
 * finais (sofit). Ficam separados dos componentes de tela de propósito,
 * para que seja fácil adicionar ou corrigir palavras/frases no futuro
 * sem precisar mexer em nenhuma lógica de interface.
 *
 * Formato de cada letra:
 * {
 *   letra:                  caractere hebraico,
 *   nome:                   nome tradicional da letra, em português,
 *   transliteracao:         transliteração aproximada da LETRA em si,
 *   pronuncia:              explicação simples de como a letra soa,
 *   exemplo:                palavra hebraica de exemplo que usa a letra,
 *   exemploTransliteracao:  transliteração da palavra de exemplo,
 *   traducao:                traducao da palavra de exemplo para português,
 *   audioTexto:             texto enviado ao mecanismo de fala (voz em hebraico)
 * }
 *
 * Nota sobre pronúncia: as explicações abaixo descrevem a pronúncia
 * moderna (israelense) do hebraico. Em vários pontos, duas letras
 * diferentes soam de forma igual ou muito parecida hoje em dia --
 * por exemplo, Alef e Ayin, Tav e Tet, Kaf (sem daguesh) e Het. Isso
 * é mencionado propositalmente em cada pronúncia: não é um erro do
 * conteúdo, é uma característica real do hebraico falado atualmente,
 * e vale a pena o estudante saber disso desde o início.
 */

export const LETRAS = [
  {
    letra: "א",
    nome: "Alef",
    transliteracao: "— / som de vogal",
    pronuncia:
      "Não tem som próprio. Na maioria das palavras é muda e serve de apoio para a vogal que vem junto dela.",
    exemplo: "אַבָּא",
    exemploTransliteracao: "Abá",
    traducao: "pai",
    audioTexto: "אַבָּא",
  },
  {
    letra: "ב",
    nome: "Bet",
    transliteracao: "B / V",
    pronuncia:
      "Com um ponto no meio (daguesh) soa como \"B\" de bola. Sem o ponto soa como \"V\" de vela.",
    exemplo: "בַּיִת",
    exemploTransliteracao: "Báyit",
    traducao: "casa",
    audioTexto: "בַּיִת",
  },
  {
    letra: "ג",
    nome: "Gimel",
    transliteracao: "G",
    pronuncia: "Som de \"G\" como em \"gato\" — sempre duro, nunca como em \"gelo\".",
    exemplo: "גָּמָל",
    exemploTransliteracao: "Gamál",
    traducao: "camelo",
    audioTexto: "גָּמָל",
  },
  {
    letra: "ד",
    nome: "Dalet",
    transliteracao: "D",
    pronuncia: "Som de \"D\" como em \"dado\".",
    exemplo: "דֶּלֶת",
    exemploTransliteracao: "Délet",
    traducao: "porta",
    audioTexto: "דֶּלֶת",
  },
  {
    letra: "ה",
    nome: "He",
    transliteracao: "H",
    pronuncia:
      "Som de \"H\" bem suave, como uma leve expiração de ar. No final de algumas palavras quase não se ouve.",
    exemplo: "הַר",
    exemploTransliteracao: "Har",
    traducao: "montanha",
    audioTexto: "הַר",
  },
  {
    letra: "ו",
    nome: "Vav",
    transliteracao: "V / U / O",
    pronuncia:
      "Como consoante soa \"V\" de vela. Também pode funcionar como vogal, com som de \"U\" ou \"O\".",
    exemplo: "וֶרֶד",
    exemploTransliteracao: "Véred",
    traducao: "rosa",
    audioTexto: "וֶרֶד",
  },
  {
    letra: "ז",
    nome: "Zayin",
    transliteracao: "Z",
    pronuncia: "Som de \"Z\" como em \"zebra\".",
    exemplo: "זַיִת",
    exemploTransliteracao: "Záyit",
    traducao: "azeitona",
    audioTexto: "זַיִת",
  },
  {
    letra: "ח",
    nome: "Het",
    transliteracao: "H gutural",
    pronuncia:
      "Som gutural, produzido no fundo da garganta — parecido com o \"J\" do espanhol (como em \"Jose\"). É diferente do Resh (ר).",
    exemplo: "חָלָב",
    exemploTransliteracao: "Haláv",
    traducao: "leite",
    audioTexto: "חָלָב",
  },
  {
    letra: "ט",
    nome: "Tet",
    transliteracao: "T",
    pronuncia: "Som de \"T\". Na pronúncia moderna soa igual ao Tav (ת).",
    exemplo: "טוֹב",
    exemploTransliteracao: "Tov",
    traducao: "bom",
    audioTexto: "טוֹב",
  },
  {
    letra: "י",
    nome: "Yod",
    transliteracao: "Y / I",
    pronuncia:
      "Como consoante soa \"Y\" (parecido com o início de \"iogurte\"). Também pode funcionar como vogal \"I\".",
    exemplo: "יָם",
    exemploTransliteracao: "Yam",
    traducao: "mar",
    audioTexto: "יָם",
  },
  {
    letra: "כ",
    nome: "Kaf",
    transliteracao: "K / Kh",
    pronuncia:
      "Com daguesh soa \"K\". Sem daguesh soa como um som gutural parecido com o Het (ח).",
    exemplo: "כֶּלֶב",
    exemploTransliteracao: "Kélev",
    traducao: "cachorro",
    audioTexto: "כֶּלֶב",
  },
  {
    letra: "ל",
    nome: "Lamed",
    transliteracao: "L",
    pronuncia: "Som de \"L\" como em \"lua\".",
    exemplo: "לֵב",
    exemploTransliteracao: "Lev",
    traducao: "coração",
    audioTexto: "לֵב",
  },
  {
    letra: "מ",
    nome: "Mem",
    transliteracao: "M",
    pronuncia: "Som de \"M\" como em \"mesa\".",
    exemplo: "מַיִם",
    exemploTransliteracao: "Máyim",
    traducao: "água",
    audioTexto: "מַיִם",
  },
  {
    letra: "נ",
    nome: "Nun",
    transliteracao: "N",
    pronuncia: "Som de \"N\" como em \"nuvem\".",
    exemplo: "נֵר",
    exemploTransliteracao: "Ner",
    traducao: "vela",
    audioTexto: "נֵר",
  },
  {
    letra: "ס",
    nome: "Samekh",
    transliteracao: "S",
    pronuncia:
      "Som de \"S\" como em \"sol\". Soa igual ao Shin quando ele tem o ponto à esquerda (chamado Sin).",
    exemplo: "סֵפֶר",
    exemploTransliteracao: "Séfer",
    traducao: "livro",
    audioTexto: "סֵפֶר",
  },
  {
    letra: "ע",
    nome: "Ayin",
    transliteracao: "— / som gutural",
    pronuncia:
      "Na pronúncia moderna costuma ser muda, de forma parecida com o Alef (א). Historicamente tinha um som gutural próprio, ainda preservado em algumas tradições de leitura.",
    exemplo: "עִיר",
    exemploTransliteracao: "Ir",
    traducao: "cidade",
    audioTexto: "עִיר",
  },
  {
    letra: "פ",
    nome: "Pe",
    transliteracao: "P / F",
    pronuncia: "Com daguesh soa \"P\". Sem daguesh soa \"F\".",
    exemplo: "פֶּרַח",
    exemploTransliteracao: "Pérach",
    traducao: "flor",
    audioTexto: "פֶּרַח",
  },
  {
    letra: "צ",
    nome: "Tsadi",
    transliteracao: "TS",
    pronuncia: "Som de \"TS\", como em \"pizza\".",
    exemplo: "צֵל",
    exemploTransliteracao: "Tsel",
    traducao: "sombra",
    audioTexto: "צֵל",
  },
  {
    letra: "ק",
    nome: "Qof",
    transliteracao: "K",
    pronuncia:
      "Som de \"K\". Na pronúncia moderna soa igual ao Kaf com daguesh (כּ).",
    exemplo: "קוֹל",
    exemploTransliteracao: "Kol",
    traducao: "voz / som",
    audioTexto: "קוֹל",
  },
  {
    letra: "ר",
    nome: "Resh",
    transliteracao: "R",
    pronuncia:
      "Som gutural produzido na garganta, mais parecido com o \"R\" do francês do que com o \"R\" do português.",
    exemplo: "רֹאשׁ",
    exemploTransliteracao: "Rosh",
    traducao: "cabeça",
    audioTexto: "רֹאשׁ",
  },
  {
    letra: "ש",
    nome: "Shin",
    transliteracao: "SH / S",
    pronuncia:
      "Com o ponto à direita soa \"SH\". Com o ponto à esquerda (chamado Sin) soa \"S\", igual ao Samekh.",
    exemplo: "שֶׁמֶשׁ",
    exemploTransliteracao: "Shémesh",
    traducao: "sol",
    audioTexto: "שֶׁמֶשׁ",
  },
  {
    letra: "ת",
    nome: "Tav",
    transliteracao: "T",
    pronuncia: "Som de \"T\". Na pronúncia moderna soa igual ao Tet (ט).",
    exemplo: "תַּפּוּחַ",
    exemploTransliteracao: "Tapuách",
    traducao: "maçã",
    audioTexto: "תַּפּוּחַ",
  },
];

/*
 * Formas finais (sofit). São as mesmas 5 letras (Kaf, Mem, Nun, Pe e
 * Tsadi), só que com um traço diferente, usado apenas quando a letra
 * aparece na última posição de uma palavra. O SOM não muda -- é a
 * mesma letra, só a forma visual é diferente no final da palavra.
 */
export const FORMAS_FINAIS = [
  {
    letra: "ך",
    nome: "Kaf final",
    origem: "כ",
    exemplo: "מֶלֶךְ",
    exemploTransliteracao: "Mélech",
    traducao: "rei",
    audioTexto: "מֶלֶךְ",
  },
  {
    letra: "ם",
    nome: "Mem final",
    origem: "מ",
    exemplo: "שָׁלוֹם",
    exemploTransliteracao: "Shalom",
    traducao: "paz / olá",
    audioTexto: "שָׁלוֹם",
  },
  {
    letra: "ן",
    nome: "Nun final",
    origem: "נ",
    exemplo: "בֵּן",
    exemploTransliteracao: "Ben",
    traducao: "filho",
    audioTexto: "בֵּן",
  },
  {
    letra: "ף",
    nome: "Pe final",
    origem: "פ",
    exemplo: "עוֹף",
    exemploTransliteracao: "Of",
    traducao: "ave",
    audioTexto: "עוֹף",
  },
  {
    letra: "ץ",
    nome: "Tsadi final",
    origem: "צ",
    exemplo: "עֵץ",
    exemploTransliteracao: "Ets",
    traducao: "árvore",
    audioTexto: "עֵץ",
  },
];

/*
 * SOM DA LETRA
 * A voz do aparelho não consegue falar uma consoante sozinha (ela precisa de
 * vogal). O som mais claro de uma letra isolada é o NOME dela (alef, bet,
 * gimel...). Este mapa guarda o nome de cada letra escrito em hebraico, e é
 * isso que o botão "Som da letra" fala. O áudio da PALAVRA de exemplo é outro.
 */
export const NOME_FALADO_DA_LETRA = {
  "א": "אלף", "ב": "בית", "ג": "גימל", "ד": "דלת", "ה": "הא", "ו": "וו", "ז": "זין",
  "ח": "חית", "ט": "טית", "י": "יוד", "כ": "כף", "ל": "למד", "מ": "מם", "נ": "נון",
  "ס": "סמך", "ע": "עין", "פ": "פא", "צ": "צדי", "ק": "קוף", "ר": "ריש", "ש": "שין", "ת": "תו",
  "ך": "כף", "ם": "מם", "ן": "נון", "ף": "פא", "ץ": "צדי",
};

// Texto que a voz deve falar para o "som da letra".
// Letra sozinha (com ou sem ponto de dagesh/shin) -> o nome dela.
// Sílaba (letra + vogal, ex.: מַ) ou outro texto -> o próprio texto.
export function audioDaLetra(texto) {
  const limpo = String(texto || "").trim();
  const base = limpo.replace(/[\u05BC\u05C1\u05C2]/g, ""); // tira dagesh e pontos do shin/sin
  return NOME_FALADO_DA_LETRA[base] || limpo;
}
