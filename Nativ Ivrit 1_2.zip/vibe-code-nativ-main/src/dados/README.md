# dados
Conteúdo do app (sem telas): letras, níveis/lições/palavras/frases/cartas, missões, Israel (cidades e pessoas), fotos e mascotes. É aqui que se acrescenta conteúdo novo.
