# componentes
Peças reutilizáveis: logo, ícones, fotos, mascotes, teclado hebraico, flashcards, questões (`SessaoQuestoes.js`), resultado (`ResumoSessao.js`), barra de navegação.
