@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================
echo  Baixar as fotos e enviar para o GitHub
echo ============================================
echo.
where node >nul 2>nul || (echo Instale o Node.js primeiro. & pause & exit /b 1)
where git >nul 2>nul || (echo Instale o Git primeiro. & pause & exit /b 1)
echo [1/3] Baixando as fotos de dominio publico...
call npm run baixar-fotos
echo.
echo [2/3] Preparando o envio...
if not exist ".git" (
  git init
  git branch -M main
  git remote add origin https://github.com/davidperelzon/Projeto-Final.git
)
git add -A
git commit -m "Adiciona fotos de Israel em dominio publico"
echo.
echo [3/3] Enviando para o GitHub (pode pedir seu login)...
git push -u origin main
echo.
echo Se apareceu erro de "rejected", rode: git pull origin main --rebase   e depois este arquivo de novo.
pause
