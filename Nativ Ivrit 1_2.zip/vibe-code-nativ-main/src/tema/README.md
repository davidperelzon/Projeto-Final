# tema
`theme.js`: todas as cores do app. Mude as cores só aqui.
