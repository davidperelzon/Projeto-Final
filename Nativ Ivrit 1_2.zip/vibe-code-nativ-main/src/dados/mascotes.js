/*
 * mascotes.js
 *
 * Mascotes do app (assets/mascotes/*.png), cada um para uma OCASIÃO. A folha
 * original ("Biblioteca visual") foi recortada em figuras separadas com fundo
 * transparente. Para trocar um mascote, substitua o arquivo PNG (mesmo nome)
 * ou aponte a ocasião para outro arquivo aqui.
 *
 * OCASIÕES USADAS NO APP:
 *   comemorando ........ tarefa aprovada (tela de sucesso)
 *   erro ............... tentativa reprovada e resposta errada
 *   joinha ............. resposta certa
 *   dica ............... "Ver dica" nas missões
 *   capituloConcluido .. prova aprovada
 *   estudando .......... tela de lição
 *   turista ............ abertura da aba Israel
 *   celebrandoIsrael ... quiz de cultura aprovado
 *   boasVindas ......... login
 * (os demais ficam disponíveis para uso futuro.)
 */
export const MASCOTES = {
  boasVindas: require("../../assets/mascotes/boas-vindas-dupla.png"),
  ola: require("../../assets/mascotes/ola.png"),
  joinha: require("../../assets/mascotes/joinha.png"),
  comemorando: require("../../assets/mascotes/comemorando.png"),
  erro: require("../../assets/mascotes/erro.png"),
  dica: require("../../assets/mascotes/dica.png"),
  capituloConcluido: require("../../assets/mascotes/capitulo-concluido.png"),
  estudando: require("../../assets/mascotes/estudando.png"),
  turista: require("../../assets/mascotes/turista.png"),
  mapaIsrael: require("../../assets/mascotes/mapa-israel.png"),
  sequencia: require("../../assets/mascotes/sequencia.png"),
  celebrandoIsrael: require("../../assets/mascotes/celebrando-israel.png"),
  falafel: require("../../assets/mascotes/falafel.png"),
  oculosA: require("../../assets/mascotes/oculos-escuros-1.png"),
  oculosB: require("../../assets/mascotes/oculos-escuros-2.png"),
  militar1: require("../../assets/mascotes/militar-1.png"),
  militar2: require("../../assets/mascotes/militar-2.png"),
};
