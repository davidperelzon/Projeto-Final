# utilitarios
Funções pequenas de apoio, como `avisar.js` (mensagens que funcionam no celular e no navegador).
