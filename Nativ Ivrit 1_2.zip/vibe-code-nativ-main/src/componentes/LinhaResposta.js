/*
 * LinhaResposta.js
 *
 * Mostra "Sua resposta" (errada) ou "Resposta correta" em NEGRITO, com ícone
 * e rótulo (não depende só de cor). Usada na correção de cada questão e na
 * lista de erros do resumo. Textos em hebraico saem da direita para a esquerda.
 *
 * Props: tipo ("errada" | "certa"), rotulo, texto, heb (true se o texto é hebraico)
 */
import React from "react";
import { StyleSheet, Text, View } from "react-native";
import Icone from "./Icone";
import { cores } from "../tema/theme";

export default function LinhaResposta({ tipo, rotulo, texto, heb }) {
  const certa = tipo === "certa";
  return (
    <View style={styles.linha} accessible accessibilityLabel={`${rotulo}: ${texto}`}>
      <Icone nome={certa ? "checkmark-circle" : "close-circle"} tamanho={20} cor={certa ? cores.sucesso : cores.erro} />
      <View style={styles.textos}>
        <Text style={styles.rotulo}>{rotulo}</Text>
        <Text style={[styles.texto, certa ? styles.certa : styles.errada, heb && styles.heb]}>{texto}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  linha: { flexDirection: "row", alignItems: "flex-start", gap: 8 },
  textos: { flex: 1 },
  rotulo: { color: cores.textoSuave, fontSize: 11, fontWeight: "800", textTransform: "uppercase", letterSpacing: 0.6 },
  texto: { fontSize: 17, fontWeight: "900", lineHeight: 24 }, // negrito
  certa: { color: cores.sucesso },
  errada: { color: cores.erro },
  heb: { fontSize: 24, lineHeight: 32, writingDirection: "rtl", textAlign: "left" },
});
