/*
 * CulturaTela.js
 *
 * Quiz de cultura da unidade (etapa "Israel: <cidade>" da trilha): 6 questões
 * com foto, pista curta e áudio do nome em hebraico, sobre a cidade e a
 * personalidade do nível. Sem texto para ler: o aluno aprende respondendo.
 *
 * REGRA DOS 60%: só quem acerta pelo menos 60% (4 de 6) conclui a etapa e
 * ganha o XP das questões e o XP da etapa (logica/aprovacao.js).
 *
 * Props: usuario, nivelId, aoResponder (registra acerto/erro),
 *        aoConcluirSessao (XP das questões), aoConcluir (XP da etapa), aoVoltar
 */
import React, { useMemo, useState } from "react";
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import SessaoQuestoes from "../componentes/SessaoQuestoes";
import { cores } from "../tema/theme";
import { CIDADE_POR_NIVEL, LUGARES } from "../dados/dadosIsrael";
import { questoesCulturaDoNivel } from "../logica/questoesCultura";

export default function CulturaTela({ usuario, nivelId, aoResponder, aoConcluirSessao, aoConcluir, aoVoltar }) {
  const [tentativa, setTentativa] = useState(0);
  const questoes = useMemo(() => questoesCulturaDoNivel(nivelId), [nivelId, tentativa]);
  const cidade = LUGARES.find((l) => l.id === CIDADE_POR_NIVEL[nivelId]);
  const jaFeito = usuario.feitos.includes(`cultura:${nivelId}`);

  // Só é chamado se a tarefa foi APROVADA: soma o XP das questões e o da etapa.
  const concluirAprovado = async (historico) => {
    const xpQuestoes = aoConcluirSessao ? await aoConcluirSessao(historico) : 0;
    const xpEtapa = jaFeito ? 0 : await aoConcluir(nivelId);
    return (xpQuestoes || 0) + (xpEtapa || 0);
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.conteudo} keyboardShouldPersistTaps="handled">
      <View style={styles.header}>
        <TouchableOpacity style={styles.voltar} onPress={aoVoltar} accessibilityRole="button" accessibilityLabel="Voltar para a trilha">
          <Text style={styles.voltarTexto}>← Trilha</Text>
        </TouchableOpacity>
        <Text style={styles.titulo} numberOfLines={1}>Israel{cidade ? `: ${cidade.nome}` : ""}</Text>
      </View>

      <SessaoQuestoes
        key={tentativa}
        questoes={questoes}
        aoResponder={aoResponder}
        aoConcluirSessao={concluirAprovado}
        aoRepetir={() => setTentativa((valor) => valor + 1)}
        aoSair={aoVoltar}
        nomeTarefa="este quiz"
        textoContinuar="Continuar na trilha"
        mascoteSucesso="celebrandoIsrael"
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: cores.fundoTela },
  conteudo: { width: "100%", maxWidth: 760, alignSelf: "center", paddingHorizontal: 16, paddingTop: 16, paddingBottom: 40 },
  header: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 14 },
  voltar: { minHeight: 44, justifyContent: "center", backgroundColor: cores.branco, borderRadius: 999, paddingHorizontal: 14, borderWidth: 1, borderColor: cores.bordaSuave },
  voltarTexto: { color: cores.azulEscuro, fontWeight: "800", fontSize: 14 },
  titulo: { flex: 1, color: cores.texto, fontSize: 20, fontWeight: "900" },
});
