/*
 * fotos.js
 *
 * Fotos usadas no app. TODAS são de DOMÍNIO PÚBLICO e vêm do Wikimedia Commons
 * (cada uma foi conferida na página do arquivo: autor e licença abaixo).
 *
 * COMO O APP CARREGA UMA FOTO (nesta ordem):
 *   1. Arquivo local em assets/fotos/<id>.jpg, se existir (veja fotosLocais.js).
 *      Para baixar todas de uma vez:  npm run baixar-fotos
 *   2. Se não houver arquivo local, carrega pela internet, pelo endereço oficial
 *      `Special:FilePath` do Commons.
 *   3. Se falhar (sem internet, arquivo renomeado), a tela mostra um bloco de cor
 *      e o app continua funcionando.
 *
 * COMO TROCAR OU ACRESCENTAR UMA FOTO:
 *   1. Abra a página do arquivo em commons.wikimedia.org e copie o nome exato
 *      (sem "File:"), por exemplo "Jerusalem Dome of the rock BW 14.JPG".
 *   2. Confira autor e licença na própria página (precisa ser domínio público).
 *   3. Acrescente um item abaixo e rode `npm run baixar-fotos`.
 */
import { FOTOS_LOCAIS } from "./fotosLocais";

export const FOTOS = {
  // ----- Cidades da viagem (uma por nível) -----
  jerusalem: {
    arquivo: "Jerusalem Dome of the rock BW 14.JPG",
    legenda: "Jerusalém: a Cúpula da Rocha, na Cidade Antiga",
    autor: "Berthold Werner",
    licenca: "domínio público",
  },
  "tel-aviv": {
    arquivo: "Statue of Mayor Meir Dizengoff on a Horse in Tel -Aviv.jpg",
    legenda: "Tel Aviv: estátua de Meir Dizengoff, o primeiro prefeito",
    autor: "Avishai Teicher",
    licenca: "domínio público",
  },
  haifa: {
    arquivo: "Haifa BW 3.JPG",
    legenda: "Haifa: o Santuário do Báb, no Monte Carmelo",
    autor: "Berthold Werner",
    licenca: "domínio público",
  },
  eilat: {
    arquivo: "Eilat2.jpg",
    legenda: "Eilat, no extremo sul de Israel",
    autor: "Tango7000",
    licenca: "domínio público",
  },
  // ----- Outros lugares -----
  tiberiades: {
    arquivo: "Hamat Tiberias mosaic writing.jpg",
    legenda: "Tiberíades: mosaico no Parque Nacional de Hamat Tiberias",
    autor: "Itai",
    licenca: "domínio público",
  },
  nazare: {
    arquivo: "Nazaret Verkuendigungsbasilika BW 16.JPG",
    legenda: "Nazaré: Basílica da Anunciação",
    autor: "Berthold Werner",
    licenca: "domínio público",
  },
  "mar-da-galileia": {
    arquivo: "Sea of Galilee 2008.JPG",
    legenda: "Mar da Galileia (Kinneret)",
    autor: "Pacman",
    licenca: "domínio público",
  },
  // ----- Personalidades -----
  herzl: {
    arquivo: "Theodor Herzl.jpg",
    legenda: "Theodor Herzl",
    autor: "autor desconhecido",
    licenca: "domínio público",
  },
  "ben-yehuda": {
    arquivo: "Eliezer Ben-Yehuda at his desk in Jerusalem - c1912.jpg",
    legenda: "Eliezer Ben-Yehuda em sua mesa, em Jerusalém (por volta de 1912)",
    autor: "Shlomo Narinsky",
    licenca: "domínio público",
  },
  "ben-gurion": {
    arquivo: "Declaration of State of Israel 1948.jpg",
    legenda: "Ben-Gurion proclama o Estado de Israel, em Tel Aviv, 14/05/1948",
    autor: "Rudi Weissenstein",
    licenca: "domínio público",
  },
  "golda-meir": {
    arquivo: "Golda Meir 03265u-2.jpg",
    legenda: "Golda Meir, em 1973",
    autor: "Marion S. Trikosko (Library of Congress)",
    licenca: "domínio público",
  },
};

// Endereço da imagem no Commons, já no tamanho pedido (largura em pixels).
export function urlFoto(id, largura = 800) {
  const foto = FOTOS[id];
  if (!foto) return null;
  return `https://commons.wikimedia.org/wiki/Special:FilePath/${encodeURIComponent(foto.arquivo)}?width=${largura}`;
}

// Fonte da imagem para o componente <Image>: arquivo local, se houver, ou internet.
export function fonteFoto(id, largura = 800) {
  if (FOTOS_LOCAIS[id]) return FOTOS_LOCAIS[id];
  const uri = urlFoto(id, largura);
  return uri ? { uri } : null;
}

export function creditoFoto(id) {
  const foto = FOTOS[id];
  return foto ? `Foto: ${foto.autor} · ${foto.licenca} · Wikimedia Commons` : "";
}
