# conta
Contas e segurança: `userDB.js` guarda usuários, XP e progresso no aparelho; `seguranca.js` faz o hash das senhas e valida os dados.
