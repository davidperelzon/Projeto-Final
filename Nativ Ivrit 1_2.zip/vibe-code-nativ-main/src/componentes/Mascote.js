/*
 * Mascote.js
 *
 * Mostra um mascote de src/dados/mascotes.js. É decorativo: leitores de tela
 * o ignoram (a informação importante sempre está também em texto).
 * Uso: <Mascote nome="comemorando" tamanho={110} />
 */
import React from "react";
import { Image } from "react-native";
import { MASCOTES } from "../dados/mascotes";

export default function Mascote({ nome, tamanho = 96, style }) {
  const fonte = MASCOTES[nome];
  if (!fonte) return null;
  return (
    <Image
      source={fonte}
      resizeMode="contain"
      style={[{ width: tamanho, height: tamanho }, style]}
      accessible={false}
      importantForAccessibility="no-hide-descendants"
    />
  );
}
