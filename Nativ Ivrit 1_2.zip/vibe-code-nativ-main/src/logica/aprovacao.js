/*
 * aprovacao.js
 *
 * REGRA DOS 60%: para concluir uma tarefa (sessão de questões, mini-prática
 * da lição, quiz de cultura ou prova) e receber XP, o aluno precisa acertar
 * pelo menos 60% das questões. Abaixo disso a tarefa continua pendente e NÃO
 * rende XP. Este é o ÚNICO lugar onde a regra existe: para mudar a nota
 * mínima, altere PERCENTUAL_MINIMO.
 *
 *   4 de 10 -> reprovado     5 de 10 -> reprovado
 *   6 de 10 -> aprovado      8 de 10 -> aprovado     10 de 10 -> aprovado
 */
export const PERCENTUAL_MINIMO = 60;

// Menor número de acertos que aprova (ex.: 10 questões -> 6; 8 -> 5; 6 -> 4; 3 -> 2).
// O "- 1e-9" evita erro de decimal (60% de 5 questões é 3, não 4).
export function minimoDeAcertos(total) {
  if (!total || total <= 0) return 0;
  return Math.ceil((total * PERCENTUAL_MINIMO) / 100 - 1e-9);
}

export function percentual(acertos, total) {
  return total > 0 ? Math.round((acertos / total) * 100) : 0;
}

// true somente se alcançou o mínimo (e a tarefa tem pelo menos 1 questão).
export function aprovou(acertos, total) {
  return total > 0 && acertos >= minimoDeAcertos(total);
}
