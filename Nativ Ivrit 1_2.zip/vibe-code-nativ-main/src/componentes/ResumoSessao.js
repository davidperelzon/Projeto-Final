/*
 * ResumoSessao.js
 *
 * Tela de RESULTADO de uma tarefa (sessão de questões, mini-prática de lição,
 * quiz de cultura ou prova). Aplica a REGRA DOS 60% (logica/aprovacao.js).
 *
 * APROVADO (>= 60%):
 *   - mascote + check animado + "כָּל הַכָּבוֹד!" / "Muito bem!";
 *   - XP só aparece se foi realmente concedido agora (`xpGanho` > 0);
 *   - botão para continuar.
 * REPROVADO (< 60%):
 *   - mensagem construtiva, acertos, percentual e mínimo necessário;
 *   - lista dos erros com "Sua resposta" e "Resposta correta" em negrito;
 *   - NENHUM XP; botão "Tentar novamente".
 * A animação respeita "reduzir movimento" do sistema e roda uma única vez.
 *
 * Props: acertos, total, historico, xpGanho, nomeTarefa, mascoteSucesso,
 *        aoTentar, aoContinuar, textoContinuar, aoSair
 */
import React, { useEffect, useRef, useState } from "react";
import { AccessibilityInfo, Animated, Platform, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import Icone from "./Icone";
import Mascote from "./Mascote";
import LinhaResposta from "./LinhaResposta";
import { cores } from "../tema/theme";
import { PERCENTUAL_MINIMO, aprovou, minimoDeAcertos, percentual } from "../logica/aprovacao";

// Check animado: cresce com uma pequena "mola". Sem animação se o aparelho pede menos movimento.
function CheckAnimado() {
  const escala = useRef(new Animated.Value(0.4)).current;
  const opacidade = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    let vivo = true;
    const nativo = Platform.OS !== "web";
    const rodar = (reduzir) => {
      if (!vivo) return;
      if (reduzir) {
        escala.setValue(1);
        opacidade.setValue(1);
        return;
      }
      Animated.parallel([
        Animated.spring(escala, { toValue: 1, friction: 5, tension: 120, useNativeDriver: nativo }),
        Animated.timing(opacidade, { toValue: 1, duration: 220, useNativeDriver: nativo }),
      ]).start();
    };
    Promise.resolve(AccessibilityInfo.isReduceMotionEnabled && AccessibilityInfo.isReduceMotionEnabled())
      .then(rodar)
      .catch(() => rodar(false));
    return () => {
      vivo = false;
    };
  }, [escala, opacidade]);

  return (
    <Animated.View style={[styles.check, { opacity: opacidade, transform: [{ scale: escala }] }]}>
      <Icone nome="checkmark" tamanho={40} cor={cores.branco} />
    </Animated.View>
  );
}

export default function ResumoSessao({
  acertos,
  total,
  historico = [],
  xpGanho = 0,
  nomeTarefa = "esta tarefa",
  mascoteSucesso = "comemorando",
  aoTentar,
  aoContinuar,
  textoContinuar = "Continuar",
  aoSair,
}) {
  const passou = aprovou(acertos, total);
  const pct = percentual(acertos, total);
  const minimo = minimoDeAcertos(total);
  const erros = historico.filter((item) => !item.acertou);
  const [verErros, setVerErros] = useState(!passou);

  return (
    <View style={[styles.cartao, passou ? styles.cartaoOk : styles.cartaoAtencao]} accessibilityLiveRegion="polite">
      {passou ? (
        <>
          <Mascote nome={mascoteSucesso} tamanho={104} />
          <CheckAnimado />
          <Text style={styles.hebraico}>כָּל הַכָּבוֹד!</Text>
          <Text style={styles.titulo}>Muito bem!</Text>
        </>
      ) : (
        <>
          <Mascote nome="erro" tamanho={92} />
          <Text style={styles.titulo}>Ainda não foi desta vez</Text>
        </>
      )}

      <Text style={styles.placar}>
        {acertos} de {total} acertos · {pct}%
      </Text>
      <View style={styles.barra} accessibilityRole="progressbar" accessibilityValue={{ min: 0, max: 100, now: pct }} accessibilityLabel={`Resultado: ${pct}%`}>
        <View style={[styles.barraCheia, passou ? styles.barraOk : styles.barraAtencao, { width: `${Math.max(pct, 3)}%` }]} />
        <View style={[styles.marca, { left: `${PERCENTUAL_MINIMO}%` }]} />
      </View>
      <Text style={styles.minimo}>
        Mínimo para passar: {minimo} de {total} ({PERCENTUAL_MINIMO}%)
      </Text>

      {passou ? (
        xpGanho > 0 ? (
          <View style={styles.xp} accessibilityLabel={`Você ganhou ${xpGanho} de experiência`}>
            <Icone nome="star" tamanho={18} cor={cores.xp} />
            <Text style={styles.xpTexto}>+{xpGanho} XP</Text>
          </View>
        ) : null
      ) : (
        <Text style={styles.mensagem}>
          Você acertou {acertos} de {total} questões. Para concluir {nomeTarefa}, precisa acertar pelo menos {PERCENTUAL_MINIMO}%. Revise suas respostas e tente novamente!
        </Text>
      )}

      {erros.length > 0 ? (
        <View style={styles.errosCaixa}>
          <TouchableOpacity onPress={() => setVerErros((v) => !v)} accessibilityRole="button" accessibilityState={{ expanded: verErros }} style={styles.errosCabecalho}>
            <Text style={styles.errosTitulo}>Revisar erros ({erros.length})</Text>
            <Icone nome={verErros ? "chevron-up" : "chevron-down"} tamanho={18} cor={cores.erro} />
          </TouchableOpacity>
          {verErros
            ? erros.map((erro, i) => (
                <View key={`${erro.id}-${i}`} style={styles.erroItem}>
                  {erro.pergunta ? <Text style={[styles.erroPergunta, erro.perguntaHeb && styles.erroPerguntaHeb]}>{erro.pergunta}</Text> : null}
                  <LinhaResposta tipo="errada" rotulo="Sua resposta" texto={erro.escolhida} heb={erro.escolhidaHeb} />
                  <LinhaResposta tipo="certa" rotulo="Resposta correta" texto={erro.correta} heb={erro.corretaHeb} />
                  {erro.explicacao ? <Text style={styles.erroExplicacao}>{erro.explicacao}</Text> : null}
                </View>
              ))
            : null}
        </View>
      ) : null}

      <View style={styles.botoes}>
        {!passou && aoTentar ? (
          <TouchableOpacity style={styles.botaoPrimario} onPress={aoTentar} accessibilityRole="button" accessibilityLabel="Tentar novamente">
            <Icone nome="refresh" tamanho={18} cor={cores.branco} />
            <Text style={styles.botaoPrimarioTexto}>Tentar novamente</Text>
          </TouchableOpacity>
        ) : null}
        {passou && aoContinuar ? (
          <TouchableOpacity style={styles.botaoPrimario} onPress={aoContinuar} accessibilityRole="button" accessibilityLabel={textoContinuar}>
            <Text style={styles.botaoPrimarioTexto}>{textoContinuar}</Text>
          </TouchableOpacity>
        ) : null}
        {!passou && aoSair ? (
          <TouchableOpacity style={styles.botaoSecundario} onPress={aoSair} accessibilityRole="button" accessibilityLabel="Voltar">
            <Text style={styles.botaoSecundarioTexto}>Voltar</Text>
          </TouchableOpacity>
        ) : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  cartao: { backgroundColor: cores.branco, borderRadius: 22, padding: 20, borderWidth: 1, alignItems: "center", gap: 10, marginBottom: 14 },
  cartaoOk: { borderColor: cores.sucesso },
  cartaoAtencao: { borderColor: cores.coral },
  check: { width: 64, height: 64, borderRadius: 32, backgroundColor: cores.sucesso, alignItems: "center", justifyContent: "center" },
  hebraico: { color: cores.sucesso, fontSize: 30, fontWeight: "900", writingDirection: "rtl" },
  titulo: { color: cores.texto, fontSize: 24, fontWeight: "900", textAlign: "center" },
  placar: { color: cores.azulEscuro, fontSize: 18, fontWeight: "800" },
  barra: { alignSelf: "stretch", height: 14, borderRadius: 999, backgroundColor: cores.progressoFundo, overflow: "hidden" },
  barraCheia: { height: "100%", borderRadius: 999 },
  barraOk: { backgroundColor: cores.sucesso },
  barraAtencao: { backgroundColor: cores.coral },
  marca: { position: "absolute", top: 0, bottom: 0, width: 3, backgroundColor: cores.azulEscuro },
  minimo: { color: cores.textoSuave, fontSize: 12, fontWeight: "800" },
  xp: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: cores.xpFundo, borderRadius: 999, paddingVertical: 8, paddingHorizontal: 16 },
  xpTexto: { color: cores.xpTexto, fontSize: 18, fontWeight: "900" },
  mensagem: { color: cores.erro, backgroundColor: cores.erroFundo, borderRadius: 12, padding: 12, fontSize: 14, lineHeight: 21, fontWeight: "700", textAlign: "center", alignSelf: "stretch" },
  errosCaixa: { alignSelf: "stretch", gap: 10 },
  errosCabecalho: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", minHeight: 44 },
  errosTitulo: { color: cores.erro, fontSize: 15, fontWeight: "900" },
  erroItem: { backgroundColor: cores.erroFundo, borderRadius: 14, padding: 12, gap: 8 },
  erroPergunta: { color: cores.texto, fontSize: 14, fontWeight: "800" },
  erroPerguntaHeb: { fontSize: 26, writingDirection: "rtl", textAlign: "left" },
  erroExplicacao: { color: cores.texto, fontSize: 13, fontWeight: "600", lineHeight: 19 },
  botoes: { alignSelf: "stretch", gap: 10, marginTop: 6 },
  botaoPrimario: { minHeight: 52, flexDirection: "row", gap: 8, backgroundColor: cores.azulEscuro, borderRadius: 14, alignItems: "center", justifyContent: "center", paddingHorizontal: 16 },
  botaoPrimarioTexto: { color: cores.branco, fontSize: 16, fontWeight: "800" },
  botaoSecundario: { minHeight: 48, backgroundColor: cores.azulGelo, borderWidth: 1, borderColor: cores.bordaSuave, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  botaoSecundarioTexto: { color: cores.texto, fontSize: 15, fontWeight: "800" },
});
