/*
 * fotosLocais.js
 *
 * ARQUIVO GERADO por `npm run baixar-fotos` (scripts/baixar-fotos.js).
 * Liga cada foto de fotos.js ao arquivo baixado em assets/fotos/. Enquanto as
 * fotos não forem baixadas, fica vazio e o app carrega tudo pela internet.
 * Não precisa editar à mão.
 */
export const FOTOS_LOCAIS = {};
