/*
 * scripts/baixar-fotos.js
 *
 * Baixa para assets/fotos/ todas as fotos listadas em fotos.js (Wikimedia
 * Commons, domínio público) e gera fotosLocais.js para o app usá-las sem
 * internet. Rode no computador com internet:
 *
 *     npm run baixar-fotos
 *
 * Depois é só enviar a pasta assets/fotos e o fotosLocais.js para o GitHub.
 * Fotos já baixadas não são baixadas de novo. Se uma falhar, o app continua
 * carregando aquela pela internet.
 */
const fs = require("fs");
const path = require("path");

const RAIZ = path.join(__dirname, "..");
const PASTA = path.join(RAIZ, "assets", "fotos");
const LARGURA = 1280; // largura pedida ao Commons (boa para celular e computador)

// Lê as fotos de fotos.js (id -> nome do arquivo no Commons).
function lerFotos() {
  const texto = fs.readFileSync(path.join(RAIZ, "src", "dados", "fotos.js"), "utf8");
  const fotos = [];
  const padrao = /^\s*"?([\w-]+)"?:\s*\{\s*\n\s*arquivo:\s*"([^"]+)"/gm;
  let m;
  while ((m = padrao.exec(texto))) fotos.push({ id: m[1], arquivo: m[2] });
  return fotos;
}

async function baixar({ id, arquivo }) {
  const destino = path.join(PASTA, `${id}.jpg`);
  if (fs.existsSync(destino) && fs.statSync(destino).size > 2000) return { id, ok: true, jaTinha: true };
  const url = `https://commons.wikimedia.org/wiki/Special:FilePath/${encodeURIComponent(arquivo)}?width=${LARGURA}`;
  try {
    const resposta = await fetch(url, { headers: { "User-Agent": "NativIvrit/1.0 (projeto escolar; fotos de dominio publico)" }, redirect: "follow" });
    if (!resposta.ok) return { id, ok: false, motivo: `HTTP ${resposta.status}` };
    const bytes = Buffer.from(await resposta.arrayBuffer());
    const ehJpeg = bytes[0] === 0xff && bytes[1] === 0xd8;
    const ehPng = bytes[0] === 0x89 && bytes[1] === 0x50;
    if (!ehJpeg && !ehPng) return { id, ok: false, motivo: "o arquivo baixado não é uma imagem" };
    fs.writeFileSync(destino, bytes);
    return { id, ok: true };
  } catch (erro) {
    return { id, ok: false, motivo: erro.message };
  }
}

(async () => {
  if (typeof fetch !== "function") {
    console.log("Use o Node 20 ou mais novo (node -v).");
    process.exit(1);
  }
  fs.mkdirSync(PASTA, { recursive: true });
  const fotos = lerFotos();
  console.log(`Baixando ${fotos.length} fotos do Wikimedia Commons...`);
  const resultados = [];
  for (const foto of fotos) {
    const r = await baixar(foto);
    resultados.push(r);
    console.log(`${r.ok ? "OK    " : "FALHOU"} ${foto.id}${r.jaTinha ? " (já existia)" : ""}${r.motivo ? " - " + r.motivo : ""}`);
  }

  // Gera fotosLocais.js só com as fotos que existem de verdade.
  const existentes = fotos.filter((f) => fs.existsSync(path.join(PASTA, `${f.id}.jpg`)));
  const linhas = existentes.map((f) => `  "${f.id}": require("../../assets/fotos/${f.id}.jpg"),`).join("\n");
  const conteudo = `/*
 * fotosLocais.js
 *
 * ARQUIVO GERADO por \`npm run baixar-fotos\` (scripts/baixar-fotos.js).
 * Liga cada foto de fotos.js ao arquivo baixado em assets/fotos/. Fotos que não
 * foram baixadas ficam de fora e o app as carrega pela internet.
 * Não precisa editar à mão.
 */
export const FOTOS_LOCAIS = {
${linhas}
};
`;
  fs.writeFileSync(path.join(RAIZ, "src", "dados", "fotosLocais.js"), conteudo);
  const falhas = resultados.filter((r) => !r.ok).length;
  console.log(`\nPronto: ${existentes.length} fotos locais, ${falhas} falha(s).`);
  console.log("Agora envie para o GitHub: git add -A && git commit -m \"Fotos de Israel\" && git push");
})();
