# audio
Serviço de áudio (voz em hebraico). `audioService.js` toca e controla o áudio; `BotaoAudio.js` é o botão; `sessaoAudio*.js` libera o som do iPhone no silencioso; `textoAudio.js` limpa o texto antes de falar.
