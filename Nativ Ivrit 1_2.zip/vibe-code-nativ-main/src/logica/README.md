# logica
Regras sem tela: trilha e níveis (`progressao.js`), sequência/metas/conquistas (`progresso.js`), regra dos 60% (`aprovacao.js`), geração de questões (`questoes*.js`).
