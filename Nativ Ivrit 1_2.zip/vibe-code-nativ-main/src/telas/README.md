# telas
Cada tela do app: trilha (`MapaProgressao.js`), alfabeto, missões, praticar, perfil, Israel, prova, quiz de cultura e login.
