/*
 * ProvaNivel.js
 *
 * PROVA DO NÍVEL: para liberar o nível seguinte, o aluno precisa ter o XP
 * mínimo (niveis.js) E passar nesta prova: 10 questões, REGRA DOS 60%
 * (logica/aprovacao.js). Aprovado: libera o nível, a próxima cidade da
 * viagem por Israel e um bônus de XP. Reprovado: nada de XP; pode revisar e
 * tentar de novo quantas vezes quiser.
 *
 * Props: usuario, nivelId, aoResponder (registra acerto/erro), aoAprovar,
 *        aoVoltar, aoRevisar
 */
import React, { useMemo, useRef, useState } from "react";
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import Logo from "../componentes/Logo";
import Icone from "../componentes/Icone";
import SessaoQuestoes from "../componentes/SessaoQuestoes";
import ResumoSessao from "../componentes/ResumoSessao";
import { cores } from "../tema/theme";
import { nivelPorId } from "../dados/niveis";
import { CIDADE_POR_NIVEL, LUGARES } from "../dados/dadosIsrael";
import { QUESTOES_NA_PROVA, montarProva } from "../logica/questoes";
import { XP_BONUS_PROVA } from "../logica/progressao";
import { PERCENTUAL_MINIMO, aprovou } from "../logica/aprovacao";

export default function ProvaNivel({ usuario, nivelId, aoResponder, aoAprovar, aoVoltar, aoRevisar }) {
  const nivel = nivelPorId(nivelId);
  const proximo = nivelPorId(nivelId + 1);
  const cidade = LUGARES.find((lugar) => lugar.id === CIDADE_POR_NIVEL[nivelId + 1]);
  const jaAprovado = usuario.nivelLiberado > nivelId;

  const [fase, setFase] = useState("regras"); // regras | prova | resultado
  const [tentativa, setTentativa] = useState(0);
  const [resumo, setResumo] = useState(null);
  const [xpBonus, setXpBonus] = useState(0);
  const [salvando, setSalvando] = useState(false);
  const finalizada = useRef(false);

  // Cada tentativa gera 10 questões novas.
  const questoes = useMemo(() => montarProva(nivelId), [nivelId, tentativa]);

  const terminar = async (dados) => {
    if (finalizada.current) return;
    finalizada.current = true;
    setResumo(dados);
    setFase("resultado");
    // Libera o nível SÓ se atingiu o mínimo (e só uma vez).
    if (aprovou(dados.acertos, dados.total) && !jaAprovado) {
      setSalvando(true);
      try {
        await aoAprovar(nivelId);
        setXpBonus(XP_BONUS_PROVA);
      } finally {
        setSalvando(false);
      }
    }
  };

  const tentarDeNovo = () => {
    finalizada.current = false;
    setResumo(null);
    setXpBonus(0);
    setTentativa((valor) => valor + 1);
    setFase("prova");
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.conteudo} keyboardShouldPersistTaps="handled">
      <View style={styles.header}>
        <TouchableOpacity style={styles.voltar} onPress={aoVoltar} accessibilityRole="button" accessibilityLabel="Voltar para a trilha">
          <Text style={styles.voltarTexto}>← Trilha</Text>
        </TouchableOpacity>
        <View style={styles.trilha}>
          <Text style={styles.trilhaTexto}>Trilha › Prova do nível {nivel.nome}</Text>
        </View>
        <Logo largura={48} />
      </View>

      {fase === "regras" ? (
        <View style={styles.cartao}>
          <Icone nome="trophy" tamanho={56} cor={cores.dourado} />
          <Text style={styles.titulo}>Prova do nível {nivel.nome}</Text>
          <Text style={styles.texto}>
            Passe na prova para liberar o nível {proximo.nome}
            {cidade ? ` e chegar a ${cidade.nome} (${cidade.heb})` : ""}.
          </Text>
          <View style={styles.regras}>
            <Text style={styles.regra}>• {QUESTOES_NA_PROVA} questões variadas</Text>
            <Text style={styles.regra}>• Para passar: acertar pelo menos {PERCENTUAL_MINIMO}%</Text>
            <Text style={styles.regra}>• Pode tentar de novo quantas vezes quiser</Text>
            <Text style={styles.regra}>• Aprovado: +{XP_BONUS_PROVA} XP de bônus</Text>
            <Text style={styles.regra}>• O que você errar vai para a Revisão</Text>
          </View>
          {jaAprovado ? <Text style={styles.aviso}>Você já passou nesta prova. Pode refazer para treinar (sem novo bônus).</Text> : null}
          <TouchableOpacity style={styles.botaoPrimario} onPress={() => setFase("prova")} accessibilityRole="button">
            <Text style={styles.botaoPrimarioTexto}>Começar a prova</Text>
          </TouchableOpacity>
        </View>
      ) : null}

      {fase === "prova" ? (
        <SessaoQuestoes key={tentativa} questoes={questoes} aoResponder={aoResponder} aoFinalizar={terminar} semResumo />
      ) : null}

      {fase === "resultado" && resumo ? (
        <>
          <ResumoSessao
            acertos={resumo.acertos}
            total={resumo.total}
            historico={resumo.historico}
            xpGanho={xpBonus}
            nomeTarefa="a prova"
            mascoteSucesso="capituloConcluido"
            aoTentar={tentarDeNovo}
            aoContinuar={salvando ? undefined : aoVoltar}
            textoContinuar={salvando ? "Salvando…" : "Continuar na trilha"}
            aoSair={aoVoltar}
          />
          {!aprovou(resumo.acertos, resumo.total) ? (
            <TouchableOpacity style={styles.botaoSecundario} onPress={aoRevisar} accessibilityRole="button">
              <Text style={styles.botaoSecundarioTexto}>Revisar meus erros em Praticar</Text>
            </TouchableOpacity>
          ) : null}
        </>
      ) : null}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: cores.fundoTela },
  conteudo: { width: "100%", maxWidth: 760, alignSelf: "center", paddingHorizontal: 16, paddingTop: 16, paddingBottom: 40 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8, marginBottom: 14 },
  voltar: { minHeight: 44, justifyContent: "center", backgroundColor: cores.branco, borderRadius: 999, paddingHorizontal: 14, borderWidth: 1, borderColor: cores.bordaSuave },
  voltarTexto: { color: cores.azulEscuro, fontWeight: "800", fontSize: 14 },
  trilha: { flex: 1, alignItems: "center" },
  trilhaTexto: { color: cores.textoSuave, fontSize: 12, fontWeight: "800", textAlign: "center" },
  cartao: { backgroundColor: cores.branco, borderRadius: 22, padding: 20, borderWidth: 1, borderColor: cores.bordaSuave, alignItems: "center", gap: 10 },
  titulo: { color: cores.texto, fontSize: 24, fontWeight: "800", textAlign: "center" },
  texto: { color: cores.texto, fontSize: 14, lineHeight: 21, fontWeight: "600", textAlign: "center" },
  regras: { alignSelf: "stretch", backgroundColor: cores.azulGelo, borderRadius: 14, padding: 14, gap: 6 },
  regra: { color: cores.texto, fontSize: 14, fontWeight: "700", lineHeight: 20 },
  aviso: { color: cores.texto, backgroundColor: cores.sucessoFundo, borderRadius: 10, padding: 10, fontSize: 13, fontWeight: "800", textAlign: "center" },
  botaoPrimario: { alignSelf: "stretch", minHeight: 50, backgroundColor: cores.azulEscuro, borderRadius: 14, alignItems: "center", justifyContent: "center", paddingHorizontal: 16 },
  botaoPrimarioTexto: { color: cores.branco, fontSize: 15, fontWeight: "800" },
  botaoSecundario: { minHeight: 48, backgroundColor: cores.azulGelo, borderWidth: 1, borderColor: cores.bordaSuave, borderRadius: 14, alignItems: "center", justifyContent: "center", paddingHorizontal: 12, marginBottom: 12 },
  botaoSecundarioTexto: { color: cores.texto, fontSize: 15, fontWeight: "800" },
});
