/*
 * theme.js
 *
 * PALETA DE CORES DO PROJETO (definida no PDF "projeto final").
 * É o ÚNICO lugar onde existem códigos de cor. Todas as telas importam
 * `cores` daqui. Para mudar a identidade visual, altere só este arquivo.
 *
 * Cores oficiais do PDF:
 *   Laranja       #F28C28  -> energia, motivação (destaques, progresso)
 *   Azul escuro   #1F4E8C  -> confiança, seriedade (títulos, botões)
 *   Azul médio    #2F6DB5  -> textos secundários, links
 *   Azul claro    #6FA4D9  -> detalhes, bordas, fundos suaves
 *   Cinza         #8896B3  -> placeholders, itens desativados
 *   Branco        #FFFFFF  -> cartões e fundos
 *   Verde musgo   #2E7D32  -> acertos, XP ganho, sucesso
 *
 * Observação: no PDF, "azul médio" e "azul mais escuro" aparecem com o
 * mesmo código (2F6DB5). Aqui foi usado #1F4E8C como "azul escuro",
 * que é a cor principal listada no próprio PDF.
 *
 * As cores "suaves" abaixo NÃO são cores novas: são as mesmas cores da
 * paleta com transparência, usadas para fundos e bordas leves.
 */
export const cores = {
  // ---- Paleta oficial ----
  laranja: "#F28C28",
  azulEscuro: "#1F4E8C",
  azulMedio: "#2F6DB5",
  azulClaro: "#6FA4D9",
  cinza: "#8896B3",
  branco: "#FFFFFF",
  verdeMusgo: "#2E7D32",

  // ---- Papéis (apelidos usados nas telas) ----
  texto: "#1F4E8C", // texto principal (contraste alto sobre branco)
  textoSuave: "#2F6DB5", // texto secundário
  textoSobreEscuro: "#FFFFFF", // texto sobre botões azul escuro / verde

  // ---- Variações com transparência (mesmas cores, mais leves) ----
  fundoTela: "rgba(111, 164, 217, 0.14)", // azul claro 14%
  fundoSuave: "rgba(111, 164, 217, 0.18)", // azul claro 18%
  bordaSuave: "rgba(111, 164, 217, 0.45)", // azul claro 45%
  destaqueSuave: "rgba(242, 140, 40, 0.20)", // laranja 20%
  sucessoSuave: "rgba(46, 125, 50, 0.14)", // verde musgo 14%

  // ---- Famílias de apoio (todas suaves; usadas só onde têm função) ----
  azulGelo: "#EAF3FB", // fundos leves e áreas de descanso
  azulCeu: "#D6E8F8", // trajeto da trilha, trilhos de barras
  verdeSuave: "#E3F4E6", // fundo de acerto/concluído
  dourado: "#F2B33D", // XP, recompensas, marcos
  douradoSuave: "#FFF1CF", // fundo de XP
  douradoTexto: "#7A5200", // texto sobre dourado suave (contraste AA)
  lilas: "#5E3FA8", // atividades especiais (cultura, prova)
  lilasSuave: "#EEE8FA",
  coral: "#E0634A", // alerta moderado (ícones)
  coralEscuro: "#B03A26", // texto de erro (contraste AA sobre coralSuave)
  coralSuave: "#FDE8E3", // fundo de erro/atenção
  bloqueadoFundo: "#E4EBF3", // etapa trancada (discreta, mas visível)
  bloqueadoTexto: "#4D5F7C",

  // ---- Papéis (use estes nomes nas telas) ----
  sucesso: "#2E7D32",
  sucessoFundo: "#E3F4E6",
  erro: "#B03A26",
  erroFundo: "#FDE8E3",
  xp: "#F2B33D",
  xpFundo: "#FFF1CF",
  xpTexto: "#7A5200",
  especial: "#5E3FA8",
  especialFundo: "#EEE8FA",
  progresso: "#2F6DB5",
  progressoFundo: "#D6E8F8",
};
