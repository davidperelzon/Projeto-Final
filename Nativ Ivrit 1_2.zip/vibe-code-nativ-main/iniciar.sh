#!/bin/sh
# Atalho para Mac e Linux: instala (na 1ª vez) e abre o app com túnel (qualquer Wi-Fi).
cd "$(dirname "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js não encontrado. Instale a versão LTS em https://nodejs.org"
  exit 1
fi
MAJOR=$(node -p "process.versions.node.split('.')[0]")
if [ "$MAJOR" -lt 20 ]; then
  echo "Seu Node.js é muito antigo. Instale o Node 22 LTS em https://nodejs.org"
  exit 1
fi
if [ ! -d node_modules ]; then
  echo "Instalando dependências pela primeira vez..."
  npm install || npm install --legacy-peer-deps
  npx expo install --fix
fi
echo "Abrindo com TÚNEL: o QR code funciona em qualquer Wi-Fi ou 4G."
npx expo start --tunnel --clear || {
  echo "O túnel não abriu. Tentando pela rede local (mesmo Wi-Fi)..."
  npx expo start --clear
}
